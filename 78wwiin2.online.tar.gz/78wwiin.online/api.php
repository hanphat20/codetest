<?php

switch ($currentURL){
    case '/api/apigetdata':
        $type = 1;
        require_once __DIR__.'/getdata.php';
        exit;
    case '/vi5prod-ecp/api/v1/register':
        $type = 2;
        require_once __DIR__.'/getdata.php';
        exit;
}

$jsonData = file_get_contents('xhr.json');
$requests = json_decode($jsonData, true);
$response = findSimilarResponse($currentURL, $requests);
function findSimilarResponse($url, $requests) {
    foreach ($requests as $request) {
        if (strpos($url, $request['url']) !== false) {
            return $request['response'];
        }
    }
    return null;
}
if ($response) {
    // Trả về response từ file JSON
    header("Content-Type: application/json");
    echo $response;
} else {

    http_response_code(404);
    echo json_encode(["error" => "Không tìm thấy dữ liệu phù hợp"]);
}