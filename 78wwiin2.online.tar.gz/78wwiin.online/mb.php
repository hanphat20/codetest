
<!doctype html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"/><link rel="shortcut icon" href="/favicons/vi5prod.ico"/><meta name="referrer" content="origin"/><meta name="google" content="notranslate"/><title>78win Trang Chính Thức | Casino Trực Tuyến Uy Tín #1 2025</title><meta http-equiv="x-dns-prefetch-control" content="on"/><link rel="preconnect" href="https://img.alltocon.com"/><link rel="dns-prefetch" href="https://img.alltocon.com"/><link rel="preconnect" href="https://api.78win2.cc"/><link rel="dns-prefetch" href="https://api.78win2.cc"/><meta name="title" content="78win - Trang chủ chính thức 78win | Đăng ký , Đăng nhập 78win."><meta name="description" content="Trải nghiệm 78win - Casino trực tuyến hàng đầu với giao dịch nhanh, bảo mật cao. Đăng ký ngay để trải nghiệm các dịch vụ uy tín và đỉnh cao."><link rel="canonical" href="https://www.78winnetwork.io/"/><meta name="robots" content="index, follow, max-snippet:-1, max-video-preview:-1, max-image-preview:large"><meta property="og:locale" content="vi_VN"><meta property="og:type" content="website"><meta property="og:title" content="78win - Trang chủ chính thức 78win | Đăng ký , Đăng nhập 78win."><meta property="og:description" content="78win ✓✓ là một thương hiệu uy tín, sản phẩm đa dạng, an ninh bảo mật, giao dịch nhanh chóng, các dịch vụ và sản phẩm chất lượng như Nổ Hũ, Bắn Cá, Thể Thao, Game Bài, Đá gà, Xổ Số, Casino."><meta property="og:image" content="https://78win86.vip/78WIN_Media/20250222094659.png"><meta property="twitter:title" content="78win - Trang chủ chính thức 78win | Đăng ký , Đăng nhập 78win."><meta property="twitter:description" content="78win ✓✓ là một thương hiệu uy tín, sản phẩm đa dạng, an ninh bảo mật, giao dịch nhanh chóng, các dịch vụ và sản phẩm chất lượng như Nổ Hũ, Bắn Cá, Thể Thao, Game Bài, Đá gà, Xổ Số, Casino."><meta property="twitter:image" content="https://78win86.vip/78WIN_Media/20250222094659.png"><style>body {
            margin: 0;
            padding: 0;
        }

        #root {
            display: none;
        }

        .app-loading-custom {
            position: fixed;
            background-color: #e4e5e5;
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100vw;
            height: calc(100vh - env(safe-area-inset-bottom));
            color: #666;
            font-family: -apple-system-font, Helvetica Neue, PingFang SC, STHeitiSC-Light, Arial, sans-serif;
            z-index: 99999999;

            > div {
                min-height: 200px;
                > h2 {
                    margin: 0.83em 0;
                }

                > p {
                    margin: 1em 0;
                }
            }
            .brand-img-wrapper {
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100px;
                width: 70vw;
                max-width: 600px;
            }
        }

        .app-loading.hide {
            opacity: 0;
        }

        .app-loading,
        .app-failure {
            position: fixed;
            background-color: #212534;
            display: flex;
            flex-flow: column wrap;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 100%;
            color: #fff;
            font-family: -apple-system-font, Helvetica Neue, PingFang SC, STHeitiSC-Light, Arial, sans-serif;
            z-index: 99999999;
        }
        .app-loading .loading-icon,
        .app-failure .loading-icon {
            width: 30px;
        }
        .loading-cont {
            position: absolute;
            bottom: 10px;
            width: 100%;
            color: #fff;
            text-shadow: 0 1px 1px #000;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 15px auto;
            font-size: 19px;
            opacity: 0.6;
            min-height: 30px;
        }
        .app-loading .logo,
        .app-failure .logo {
            width: 80%;
            max-width: 300px;
        }
        .app-failure h1 {
            width: 100%;
            color: #efefef;
            font-size: 28px;
            font-weight: 500;
            text-align: center;
        }
        .app-failure .cont {
            padding: 0 20px;
        }
        .app-failure .cont span {
            font-size: 14px;
        }
        .app-failure li {
            margin: 10px 0;
        }
        .app-failure .btn-refresh {
            display: block;
            text-decoration: none;
            margin-top: 10px;
            line-height: 42px;
            width: 120px;
            text-align: center;
            color: #666;
            border: 1px solid #888;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 800;
            background-color: rgba(255, 255, 255, 0.5);
            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.3);
        }
        .app-failure .cont span.version-hash {
            font-size: 12px;
        }
        @property --rotate {
            syntax: '<angle>';
            initial-value: 132deg;
            inherits: false;
        }
        :root {
            --card-height: 65vh;
            --card-width: 70vw;
        }
        .main-cont {
            box-sizing: border-box;
            background: rgba(25, 28, 41, 0.95);
            width: var(--card-width);
            height: var(--card-height);
            max-width: 600px;
            padding: 3px;
            position: relative;
            border-radius: 10px;
            justify-content: center;
            align-items: center;
            text-align: center;
            display: flex;
            flex-wrap: wrap;
        }
        .main-cont .brand .loading-msg {
            padding: 0 5px;
            margin: 0.3em 0 0.83em 0;
        }
        .main-cont .brand .loading-msg,
        .main-cont .brand .loading-msg b {
            font-weight: normal;
            line-height: 1.4;
            font-size: 19px;
        }
        .main-cont .brand {
            height: 50%;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-content: center;

            .brand-img-wrapper {
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100px;
                width: 70vw;
                max-width: 600px;

                .new-logo {
                    position: absolute;
                    width: 95vw;
                    max-width: 537.5px;
                }
            }
        }
        .main-cont .brand .loading-msg {
            width: 100%;
        }
        .main-cont .brand .loading-msg b + span {
            display: none;
        }
        .main-cont::before {
            content: '';
            width: calc(100% + 6px);
            height: calc(100% + 6px);
            border-radius: 13px;
            background-image: linear-gradient(var(--rotate), #5ddcff, #3c67e3 43%, #4e00c2);
            position: absolute;
            z-index: -1;
            top: -3px;
            left: -3px;
            animation: light-spin 4.5s linear infinite;
        }

        .main-cont::after {
            position: absolute;
            content: '';
            top: calc(var(--card-height) / 6);
            left: 0;
            right: 0;
            z-index: -1;
            height: 100%;
            width: 100%;
            margin: 0 auto;
            transform: scale(0.8);
            filter: blur(calc(var(--card-height) / 6));
            background-image: linear-gradient(var(--rotate), #5ddcff, #3c67e3 43%, #4e00c2);
            opacity: 1;
            transition: opacity 0.5s;
            animation: light-spin 4.5s linear infinite;
        }

        @keyframes light-spin {
            0% {
                --rotate: 0deg;
            }
            100% {
                --rotate: 360deg;
            }
        }</style><script defer="defer" src="/static/js/runtimechunkmain.27f7419a.js"></script><script defer="defer" src="/static/js/vendor-moment.31f5b79e.js"></script><script defer="defer" src="/static/js/r16-dom.9673ff4f.js"></script><script defer="defer" src="/static/js/vendor.8ee801c6.js"></script><script defer="defer" src="/static/js/main.a41700d5.js?v=6"></script><meta name="apple-mobile-web-app-title" content="78win" /><meta name="apple-mobile-web-app-capable" content="yes" /><meta name="apple-mobile-web-app-status-bar-style" content="#f5f6f9" /><meta name="theme-color" content="#EFEFEF" /><link rel="apple-touch-icon" sizes="512x512" href="/icon_512x512.5ad13f00bd4ae8122867b10e24459e46.png" /><link rel="apple-touch-icon" sizes="384x384" href="/icon_384x384.2b2b76c2ed16e0f9869a5186fa6931ed.png" /><link rel="apple-touch-icon" sizes="192x192" href="/icon_192x192.6c6e357b935c2b61e85b0d063ad63ede.png" /><link rel="apple-touch-icon" sizes="152x152" href="/icon_152x152.417d796d0cf29b4df8dbfdc04bfd6aa0.png" /><link rel="apple-touch-icon" sizes="144x144" href="/icon_144x144.8ce08be96b9b688450078ffd142b726e.png" /><link rel="apple-touch-icon" sizes="128x128" href="/icon_128x128.4d1ea4b47bb60e97d86d26b2a7726d17.png" /><link rel="apple-touch-icon" sizes="72x72" href="/icon_72x72.6302ff04a6cad8c6b2b0cdc8d57dfa50.png" /><link rel="apple-touch-icon" sizes="96x96" href="/icon_96x96.c484570a346e5d1e4d372cf1b527748c.png" /><link rel="manifest" href="/manifest.1b62b641cd6d2b519f16159ac8591141.json" /><link rel="preload" as="script" href="/static/js/i18n-vi-VN.e7b5412b.js">
</head><body><div id="root"></div><div class="app-loading-custom"></div><style>.app-loading-custom {
        display: flex;
        align-items: center;
        justify-content: center;
        background: url(https://img.alltocon.com/img/static/vi5prod/loading/loading-pc.webp)
        center/contain no-repeat;
    }
    @media (max-width: 768px) {
        .app-loading-custom {
            background: url(https://img.alltocon.com/img/static/vi5prod/loading/loading-h5.webp)
            center/contain no-repeat;
        }
    }</style><div id="modal-root"></div><script>/* REPLACE START */
    /* REPLACE END */</script><script type="application/ld+json">{
        "@context": "https://schema.org",
        "@type": "Casino",
        "@id": "https://www.78wine.vip/gamelobby/live",
        "name": "78win - Trang chủ chính thức 78win | Đăng ký , Đăng nhập 78win.",
        "legalName": "78win - Trang chủ chính thức 78win | Đăng ký , Đăng nhập 78win.",
        "description": "78win ✓✓ là một thương hiệu uy tín, sản phẩm đa dạng, an ninh bảo mật, giao dịch nhanh chóng, các dịch vụ và sản phẩm chất lượng như Nổ Hũ, Bắn Cá, Thể Thao, Game Bài, Đá gà, Xổ Số, Casino.",
        "url": "https://www.78wine.vip/",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Số 72, phố Thụy Khuê, Phường Thuỵ Khuê",
            "addressLocality": "Quận Tây Hồ",
            "addressRegion": "Hà Nội",
            "postalCode": "100000",
            "addressCountry": {
                "@type": "Country",
                "name": "VN"
            }
        },
        "sameAs": [
            "https://www.facebook.com/KCT78WIN",
            "https://www.78wine.vip/info/aboutUs",
            "https://78win80.com/cskh/youtube",
            "https://78win80.com/cskh/telegram"
        ],
        "currenciesAccepted": "VND",
        "paymentAccepted": ["Bank", "USDT", "Momo Pay", "Zalo Pay"],
        "priceRange": "$",
        "email": "admin@78win.com",
        "telephone": "0763067872",
        "knowsLanguage": ["vi"],
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            "opens": "00:00",
            "closes": "24:00"
        },
        "contactPoint": {
            "@type": "ContactPoint",
            "email": "admin@78win.com",
            "telephone": "0763067872",
            "areaServed": "VN"
        },
        "image": {
            "@type": "ImageObject",
            "url": "https://78win86.vip/78WIN_Media/20250222094659.png",
            "width": 1200,
            "height": 630
        },
        "logo": {
            "@type": "ImageObject",
            "url": "https://78win86.vip/78WIN_Media/20250222094659.png",
            "width": 600,
            "height": 60
        },
        "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.8",
            "reviewCount": "254"
        }
    }</script><script type="application/ld+json">{
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
            {
                "@type": "ListItem",
                "position": 1,
                "name": "Nổ Hũ",
                "item": "https://www.78wine.vip/gamelobby/egame"
            },
            {
                "@type": "ListItem",
                "position": 2,
                "name": "Bắn Cá",
                "item": "https://www.78wine.vip/gamelobby/mpg"
            },
            {
                "@type": "ListItem",
                "position": 3,
                "name": "Đăng Nhập",
                "item": "https://www.78wine.vip/#Login"
            },
            {
                "@type": "ListItem",
                "position": 4,
                "name": "Đăng Ký",
                "item": "https://www.78wine.vip/#Register"
            },
            {
                "@type": "ListItem",
                "position": 5,
                "name": "Casino",
                "item": "https://www.78wine.vip/gamelobby/live"
            }
        ]
    }</script><script type="application/ld+json">{
        "@context": "https://schema.org",
        "@type": "Event",
        "name": "Kỷ Niệm Thành Lập 78win",
        "startDate": "2025-08-01T00:00+07:00",
        "endDate": "2025-08-31T23:59",
        "eventAttendanceMode": "https://schema.org/OnlineEventAttendanceMode",
        "eventStatus": "https://schema.org/EventScheduled",
        "location": {
            "@type": "VirtualLocation",
            "url": "https://www.78wine.vip/promotions"
        },
        "organizer": {
            "@type": "Organization",
            "name": "78win",
            "url": "https://www.78wine.vip/"
        },
        "performer": {
            "@type": "Person",
            "name": "78win Official Host"
        },
        "description": "Tham gia sự kiện đặc biệt nhân dịp Kỷ Niệm Thành Lập 78win, Lì Xì hấp dẫn và hoạt động thú vị đang chờ bạn!",
        "image": "https://78win86.vip/78WIN_Media/20250222094659.png",
        "offers": {
            "@type": "Offer",
            "url": "https://www.78wine.vip/promotions",
            "price": "0",
            "priceCurrency": "VND",
            "availability": "https://schema.org/InStock",
            "validFrom": "2025-08-01T00:00"
        }
    }</script><script type="application/ld+json">{
        "@context": "https://schema.org",
        "@type": "SoftwareApplication",
        "name": "78win - Trang chủ chính thức 78win | Đăng ký , Đăng nhập 78win.",
        "operatingSystem": ["Android", "iOS"],
        "applicationCategory": "Game",
        "downloadUrl": "https://www.78wine.vip/",
        "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.7",
            "reviewCount": "1200"
        },
        "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "VND",
            "availability": "https://schema.org/InStock"
        },
        "description": "Tải APP 78win để trải nghiệm sòng bài trực tuyến, chơi mọi lúc mọi nơi và nhận ưu đãi lớn."
    }</script><script type="application/ld+json">{
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": "Làm thế nào để tải APP 78win?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Bạn có thể tải ứng dụng 78win trên các thiết bị Android và iOS thông qua trang web chính thức: https://78winapp01.pages.dev/"
                }
            },
            {
                "@type": "Question",
                "name": "Làm sao để nhận code miễn phí tại 78win?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Hãy tham gia ngay kênh telegaram 78win phát code mỗi ngày để nhận thưởng."
                }
            },
            {
                "@type": "Question",
                "name": "78win kinh doanh có hợp pháp không?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "78win là một nhà cái có giấy phép cá cược trực tuyến hợp pháp do Isle of Man và Khu kinh tế Cagayan and Freeport cấp."
                }
            },
            {
                "@type": "Question",
                "name": "Các hình thức thanh toán nào được hỗ trợ?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "78win hỗ trợ nhiều hình thức thanh toán như Bank, USDT, Momo Pay, và Zalo Pay."
                }
            }
        ]
    }</script><script type="application/ld+json">{
        "@context": "https://schema.org",
        "@type": "Article",
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "https://www.78wine.vip/promotions"
        },
        "headline": "78win - Trang chủ chính thức 78win | Đăng ký , Đăng nhập 78win.",
        "description": "78win ✓✓ là một thương hiệu uy tín, sản phẩm đa dạng, an ninh bảo mật, giao dịch nhanh chóng, các dịch vụ và sản phẩm chất lượng như Nổ Hũ, Bắn Cá, Thể Thao, Game Bài, Đá gà, Xổ Số, Casino.",
        "image": "https://www.78wine.vip/78WIN_Media/20250222094659.png",
        "author": {
            "@type": "Person",
            "name": "Admin 78win",
            "url": "https://www.78wine.vip/author/admin/"
        },
        "publisher": {
            "@type": "Organization",
            "name": "78win",
            "logo": {
                "@type": "ImageObject",
                "url": "https://www.78wine.vip/78WIN_Media/20250222094659.png"
            }
        },
        "datePublished": "2025-01-18T00:00:00+07:00",
        "dateModified": "2026-01-01T00:00:00+07:00"
    }</script><template id="lazy-load-script-section"></template><script>// setTimeout(function () {
    //   if (!window.appIsMounted) {
    //     document.getElementById('root').innerHTML = '<div class="app-failure"><h1>Connector break</h1><div class="cont">Page cannot be accessed. Please confirm the following conditions:<ul><li>Operating system too old </br><span>(iOS 10.0+/Android 5.0+ supported)</span></li><li>Browser version too old or SSL connection error</br><span>(Recommend Chrome 50+)</span></li><li>Good network environment</li><span class="version-hash">"0a93381971298ef1d43f2923ca58bead0403fed0"</span></ul></div><a href="/" class="btn-refresh">Refresh</a></div>';
    //   }
    // }, 15000);</script><script>window.addEventListener('load', () => {
        try {
            const tpl = document.getElementById('lazy-load-script-section');
            if (tpl && tpl.content && tpl.content.hasChildNodes()) {
                const frag = tpl.content.cloneNode(true);
                document.body.appendChild(frag);
            }
        } catch (e) {
            console.log('script load Error : ', e);
        }
    });</script><div class="version-hash" style="display:none;">"0a93381971298ef1d43f2923ca58bead0403fed0"</div>
<style>
    /* Modal Overlay */
    .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 1000;
    }

    .modal-overlay.show {
        display: flex;
    }

    /* Modal Container */
    .modal-container32 {
        background: url(https://img.alltocon.com/img/static/vi5prod/login/bg-h5.jpg) 50% / cover no-repeat;
        height: unset !important;
        padding: 20px 15px;
    }

    @keyframes modalFadeIn {
        from {
            opacity: 0;
            transform: scale(0.7);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }

    /* Modal Header */
    .modal-header {
        border-bottom: 1px solid #e9ecef;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .modal-title {
        margin: 0;
        font-size: 1.25rem;
        font-weight: 600;
        color: #333;
    }

    .close-btn {
        background: none;
        border: none;
        font-size: 1.5rem;
        cursor: pointer;
        color: #999;
        padding: 0;
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: all 0.2s;
    }

    .close-btn:hover {
        background-color: #f8f9fa;
        color: #666;
    }

    /* Modal Body */
    .modal-body {
        padding: 20px;
    }

    /* Form Styles */


    .form-label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: #333;
    }

    .form-control {
        background-color: #0000 !important;
        background-position: 8px !important;
        background-repeat: no-repeat !important;
        background-size: auto 70% !important;
        border: 1px solid #215aa1 !important;
        border-radius: 7px !important;
        box-shadow: unset !important;
        color: #215aa1 !important;
        font-size: 14px !important;
        height: 40px !important;
        margin: unset;
        padding: unset;
        padding: unset !important;
        text-indent: 42px !important;
        width: 100%;
    }


    .form-control:focus {
        outline: none;
        border-color: #007bff;
        box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.1);
    }

    /* Button Styles */
    .btn {
        background: linear-gradient(180deg, #e75905, #fc8602);
        box-shadow: inset 0 0 0 1px #fff, 0 2px 4px rgba(74, 6, 152, .5);
        font-size: 21px;
        font-weight: 700;
        height: unset;
        line-height: 40px;
        text-transform: uppercase;
    }

    .btn-primary {
        background-color: #007bff;
        color: white;
    }

    .btn-primary:hover:not(:disabled) {
        background-color: #0056b3;
    }

    .btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }
    #btnxacthuc{
        background:#1974e6;
        font-size: 21px;
        font-weight: 700;
        height: unset;
        line-height: 40px;
        text-transform: uppercase;
        width: 100%;
        background-color: #7240ff;
        border: none;
        border-radius: 3px;
        color: #fff;
        cursor: pointer;
        font-size: 16px;
        font-stretch: normal;
        font-style: normal;
        height: 44px;
        width: 100%;
        border-radius: 100px;
        position: relative;
    }

    /* Spinner */
    .spinner {
        display: none;
        width: 20px;
        height: 20px;
        border: 2px solid #ffffff;
        border-top: 2px solid transparent;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin-right: 8px;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    /* Demo Button */
    .demo-btn {
        background-color: #28a745;
        color: white;
        padding: 12px 24px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 16px;
        margin-bottom: 20px;
    }

    .demo-btn:hover {
        background-color: #218838;
    }

    /* Responsive */
    @media (max-width: 576px) {
        .modal-container32 {
            width: 95%;
            margin: 10px;
        }

        .modal-header, .modal-body {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }
    }
    span.valid {
        color: #000;
        font-size: 15px;
        font-weight: 700;
        text-transform: capitalize;
        line-height: 30px;
    }
</style>
<div id="exampleModal2" class="modal-overlay">
    <div class="modal-container32">

        <div class="modal-body">
            <form id="xacthuc-phone" style="
    width: 100%;
">
                <div class="form-group" style="margin-bottom: 1em;">
                    <span class="valid" style="margin-left: .5em">
            XÁC THỰC SDT:
          </span>
                    <input type="number" class="form-control" id="exampleInputEmail1" placeholder="Nhập sdt của bạn" required="">
                </div>
                <div class="form-group">
                    <button type="submit" id="btnxacthuc" class="btn btn-primary">
                        <span id="btn-text">Xác Thực</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
</body></html>